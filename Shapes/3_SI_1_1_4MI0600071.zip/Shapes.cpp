#include <iostream>
#include "Controller.h"

int main()
{
    ShapeCollection sc;
    Start(&sc);
}